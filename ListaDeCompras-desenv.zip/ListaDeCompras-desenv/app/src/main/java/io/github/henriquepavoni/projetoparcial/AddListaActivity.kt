package io.github.henriquepavoni.projetoparcial

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.github.dhaval2404.imagepicker.ImagePicker

class AddListaActivity : AppCompatActivity() {

    private lateinit var selectedImageView: ImageView
    private lateinit var nameListInput: EditText
    private lateinit var selectImageButton: AppCompatButton
    private lateinit var addListaButton: AppCompatButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_addlista)

        selectedImageView = findViewById(R.id.selectedImageView)
        nameListInput = findViewById(R.id.nameList)
        selectImageButton = findViewById(R.id.selectImageButton)
        addListaButton = findViewById(R.id.AddListaButton)

        selectImageButton.setOnClickListener {
            // Função para selecionar imagem
            ImagePicker.with(this)
                .crop()
                .compress(1024)
                .maxResultSize(1080, 1080)
                .start()
        }

        addListaButton.setOnClickListener {
            val listName = nameListInput.text.toString()

            if (listName.isEmpty()) {
                Toast.makeText(this, "Por favor, insira o nome da lista", Toast.LENGTH_SHORT).show()
            } else {
                // Exibe a mensagem de sucesso
                Toast.makeText(this, "Lista '$listName' adicionada com sucesso!", Toast.LENGTH_SHORT).show()

                // Redireciona o usuário para a ListasActivity
                val intent = Intent(this, ListasActivity::class.java)
                startActivity(intent)

                // Fecha a AddListaActivity
                finish()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            val fileUri: Uri = data?.data!!
            selectedImageView.setImageURI(fileUri)
        } else if (resultCode == ImagePicker.RESULT_ERROR) {
            Toast.makeText(this, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Task Cancelled", Toast.LENGTH_SHORT).show()
        }
    }
}
