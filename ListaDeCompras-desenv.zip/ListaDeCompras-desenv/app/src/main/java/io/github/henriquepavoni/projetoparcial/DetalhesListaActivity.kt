package io.github.henriquepavoni.projetoparcial

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetalhesListaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inside_list)

        val tvDetalhes = findViewById<TextView>(R.id.tvDetalhes)

        val tituloLista = intent.getStringExtra("TITULO_LISTA")
        tvDetalhes.text = "Itens da lista: $tituloLista"
    }
}
