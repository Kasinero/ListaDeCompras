package io.github.henriquepavoni.projetoparcial

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

data class ListaCompra(var titulo: String)

class ListasActivity : AppCompatActivity() {

    private val listas = mutableListOf<ListaCompra>()             // Lista principal
    private val listasFiltradas = mutableListOf<ListaCompra>()    // Lista filtrada (para busca)
    private lateinit var adapter: ListaAdapter

    private lateinit var etBuscar: EditText
    private lateinit var rvListas: RecyclerView
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var btnLogout: Button // Referência para o botão de logout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lists)

        etBuscar = findViewById(R.id.etBuscar)
        rvListas = findViewById(R.id.rvListas)
        fabAdd = findViewById(R.id.fabAdd)
        btnLogout = findViewById(R.id.btnLogout)  // Referência para o botão de logout

        adapter = ListaAdapter(listasFiltradas)
        rvListas.layoutManager = LinearLayoutManager(this)
        rvListas.adapter = adapter

        listasFiltradas.addAll(listas)

        fabAdd.setOnClickListener {
            mostrarDialogo()
        }

        etBuscar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filtrarListas(s.toString())
            }
        })

        // Adicionando o OnClickListener no botão de logout
        btnLogout.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java) // Redireciona para a MainActivity
            startActivity(intent)
            finish()  // Finaliza a atividade atual
        }
    }

    private fun mostrarDialogo(listaExistente: ListaCompra? = null) {
        val dialogView = layoutInflater.inflate(R.layout.activity_dialog_lista, null)
        val etTitulo = dialogView.findViewById<EditText>(R.id.etTitulo)

        if (listaExistente != null) {
            etTitulo.setText(listaExistente.titulo)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (listaExistente != null) "Editar Lista" else "Adicionar lista")
            .setView(dialogView)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar", null)
            .create()

        dialog.show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val titulo = etTitulo.text.toString().trim()
            if (titulo.isNotEmpty()) {
                if (listaExistente != null) {
                    listaExistente.titulo = titulo
                } else {
                    listas.add(ListaCompra(titulo))
                }

                listas.sortBy { it.titulo.lowercase() }

                filtrarListas(etBuscar.text.toString())
                dialog.dismiss()
            } else {
                etTitulo.error = "Por favor, insira um título válido"
            }
        }
    }

    private fun filtrarListas(texto: String) {
        listasFiltradas.clear()
        val textoLower = texto.lowercase()
        if (textoLower.isEmpty()) {
            listasFiltradas.addAll(listas)
        } else {
            listasFiltradas.addAll(
                listas.filter { it.titulo.lowercase().contains(textoLower) }
            )
        }
        adapter.notifyDataSetChanged()
    }

    inner class ListaAdapter(private val listas: List<ListaCompra>) :
        RecyclerView.Adapter<ListaAdapter.ListaViewHolder>() {

        inner class ListaViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
            val tvTitulo: TextView = itemView.findViewById(R.id.tvTituloItem)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListaViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.activity_item_lista, parent, false)
            return ListaViewHolder(view)
        }

        override fun onBindViewHolder(holder: ListaViewHolder, position: Int) {
            val lista = listas[position]
            holder.tvTitulo.text = lista.titulo

            holder.itemView.setOnClickListener {
                val intent = Intent(this@ListasActivity, DetalhesListaActivity::class.java)
                intent.putExtra("tituloLista", lista.titulo)
                startActivity(intent)
            }
        }

        override fun getItemCount(): Int = listas.size
    }
}
